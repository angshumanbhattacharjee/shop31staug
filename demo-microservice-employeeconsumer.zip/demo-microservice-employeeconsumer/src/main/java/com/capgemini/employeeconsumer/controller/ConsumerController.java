package com.capgemini.employeeconsumer.controller;

import java.io.IOException;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class ConsumerController {

	@RequestMapping(value="/getemployee", method=RequestMethod.GET)
	public String getEmployee() {
		String baseurl= "http://localhost:8085/employee";
		RestTemplate resttemplate= new RestTemplate();
		ResponseEntity<String>response=null;
		
		try {
			response= resttemplate.exchange(baseurl, HttpMethod.GET, getHeaders(), String.class);
		} catch(Exception ex) {
			System.out.println(response.getBody());
		}
		
		System.out.println(response.getBody());
		return response.getBody();
		
		
	}
	private static HttpEntity<?> getHeaders() throws IOException{
		HttpHeaders headers= new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity<>(headers);
	}
}
