package com.example.demo.test;

import org.junit.Test;

import com.example.demo.repository.ProductRepository;
import com.example.demo.service.ProductService;

public class TestProduct {

	ProductService p;
	
	public void testprod() {
		System.out.println(p.findByPname("light")); 
	}
	public static void main(String[] args) {
		
		TestProduct test= new TestProduct();
		test.testprod();
	}
}
