package com.capgemini.bechdalo.group7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Group7Application {

	public static void main(String[] args) {
		SpringApplication.run(Group7Application.class, args);
	}
}
